# dial gauge reader > for needle detection
https://universe.roboflow.com/camera-ai-8ja2l/dial-gauge-reader-br6k6

Provided by a Roboflow user
License: CC BY 4.0

just to skip my mundane task to read the dial by my own eyess
